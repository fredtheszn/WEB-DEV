function submitForm(event) {
  event.preventDefault();
  alert('Thanks for your message! I will get back to you soon.');
}
